const express = require('express');
const mysql = require('mysql2');

const app = express();
const port = 3000;

// Middleware to parse incoming JSON data
app.use(express.json());  // This parses the JSON request body

// Create a connection pool to the MySQL database
const db = mysql.createPool({
    host: 'wayne.cs.uwec.edu',  // Your MySQL host
    user: 'WELDRT2820',         // Your MySQL username
    password: 'HFMM3N9I',       // Your MySQL password
    database: 'cs485group2'      // Your MySQL database
});

// API route to get all users
app.get('/users', (req, res) => {
    const query = 'SELECT * FROM users';
    
    // Query the database
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results);  // Send the results back to the client
        }
    });
});

// POST route to insert a new user into the database
app.post('/users', (req, res) => {
    const { name, username, password } = req.body;

    // Validate that all required fields are present
    if (!name || !username || !password) {
        return res.status(400).json({ error: 'Name, Username, and Password are required!' });
    }

    const query = 'INSERT INTO users (name, username, password) VALUES (?, ?, ?)';
    
    // Insert the new user into the database
    db.query(query, [name, username, password], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        // Respond with a success message
        res.status(201).json({ message: 'User added successfully!', userId: result.insertId });
    });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Check if the username and password were provided
    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Username and password are required!' });
    }

    // Query the database to find the user with the provided username and password
    const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error("Database error:", err);  // Log the full error
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        if (results.length > 0) {
            const user = results[0];
            return res.status(200).json({
                success: true,
                userId: user.user_id,
                name: user.name,
                username: user.username,
                password: user.password
            });
        } else {
            return res.status(401).json({ success: false, message: 'Invalid username or password!' });
        }
    });
});

app.get('/checkUsername', (req, res) => {
    const { username } = req.query;

    const query = 'SELECT COUNT(*) AS count FROM users WHERE username = ?';
    db.query(query, [username], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const exists = results[0].count > 0;
        res.json({ exists });
    });
});

app.put('/updatePurchase', (req, res) => {
    const { id, item_name, price, category } = req.body;

    if (!id || !item_name || !price || !category) {
        return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    const query = 'UPDATE cs485group2.purchases SET item_name = ?, price = ?, category = ? WHERE purchase_id = ?';
    db.query(query, [item_name, price, category, id], (err, result) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Database error' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Purchase not found' });
        }
        res.json({ success: true, message: 'Purchase updated successfully' });
    });
});

app.delete('/deletePurchase/:id', (req, res) => {
    const purchaseId = req.params.id;
    
    if (!purchaseId) {
        return res.status(400).json({ success: false, message: 'Purchase ID is required' });
    }
    
    const query = 'DELETE FROM cs485group2.purchases WHERE purchase_id = ?';
    db.query(query, [purchaseId], (err, result) => {
        if (err) {
            console.error("Database error: ", err);
            return res.status(500).json({ success: false, message: 'Database error' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Purchase not found' });
        }
        res.json({ success: true, message: 'Purchase deleted successfully' });
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

app.get('/purchases/:userId', (req, res) => {
    const userId = req.params.userId;

    const query = 'SELECT * FROM purchases WHERE user_id = ?';
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        // Return all purchases for the user
        res.status(200).json({ success: true, purchases: results });
    });
});

app.get('/purchases/:userId/:category', (req, res) => {
    const userId = req.params.userId;
    const catetory = req.params.category;

    const query = 'SELECT * FROM purchases WHERE user_id = ? AND category = ?';
    db.query(query, [userId, catetory], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        // Return all purchases for the user
        res.status(200).json({ success: true, purchases: results });
    });
});

app.get('/lists/:userId', (req, res) => {
    const userId = req.params.userId;

    const query = 'SELECT * FROM lists WHERE user_id = ?';
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        res.status(200).json({ success: true, lists: results });
    });
});

app.get('/purchasesByIds', (req, res) => {
    const purchaseIds = req.query.ids;

    const query = `SELECT * FROM purchases WHERE id IN (${purchaseIds})`;
    db.query(query, (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        res.status(200).json({ success: true, purchases: results });
    });
});

