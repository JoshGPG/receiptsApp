const express = require('express');
const mysql = require('mysql2');

const app = express();
const port = 3000;

app.use(express.json());

const db = mysql.createPool({
    host: 'wayne.cs.uwec.edu', 
    user: 'WELDRT2820', 
    password: 'HFMM3N9I', 
    database: 'cs485group2' 
});

app.get('/', (req, res) => {
    res.send('Server is running');
});

app.get('/users', (req, res) => {
    const query = 'SELECT * FROM users';
    

    db.query(query, (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results); 
        }
    });
});

app.post('/users', (req, res) => {
    const { name, username, password } = req.body;

    if (!name || !username || !password) {
        return res.status(400).json({ error: 'Name, Username, and Password are required!' });
    }

    const query = 'INSERT INTO users (name, username, password) VALUES (?, ?, ?)';
    
    db.query(query, [name, username, password], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ message: 'User added successfully!', userId: result.insertId });
    });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Username and password are required!' });
    }

    const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        if (results.length > 0) {
            const user = results[0];
            return res.status(200).json({
                success: true,
                userId: user.user_id,
                name: user.name,
                username: user.username,
                password: user.password
            });
        } else {
            return res.status(401).json({ success: false, message: 'Invalid username or password!' });
        }
    });
});

app.get('/checkUsername', (req, res) => {
    const { username } = req.query;

    const query = 'SELECT COUNT(*) AS count FROM users WHERE username = ?';
    db.query(query, [username], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const exists = results[0].count > 0;
        res.json({ exists });
    });
});

app.put('/updatePurchase', (req, res) => {
    const { id, item_name, price, category } = req.body;

    if (!id || !item_name || !price || !category) {
        return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    const query = 'UPDATE cs485group2.purchases SET item_name = ?, price = ?, category = ? WHERE purchase_id = ?';
    db.query(query, [item_name, price, category, id], (err, result) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Database error' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Purchase not found' });
        }
        res.json({ success: true, message: 'Purchase updated successfully' });
    });
});

app.delete('/deletePurchase/:id', (req, res) => {
    const purchaseId = req.params.id;
    
    if (!purchaseId) {
        return res.status(400).json({ success: false, message: 'Purchase ID is required' });
    }
    
    const query = 'DELETE FROM cs485group2.purchases WHERE purchase_id = ?';
    db.query(query, [purchaseId], (err, result) => {
        if (err) {
            console.error("Database error: ", err);
            return res.status(500).json({ success: false, message: 'Database error' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Purchase not found' });
        }
        res.json({ success: true, message: 'Purchase deleted successfully' });
    });
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

app.get('/purchases/:userId', (req, res) => {
    const userId = req.params.userId;

    const query = 'SELECT * FROM purchases WHERE user_id = ?';
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        res.status(200).json({ success: true, purchases: results });
    });
});

app.get('/purchases/:userId/:category', (req, res) => {
    const userId = req.params.userId;
    const catetory = req.params.category;

    const query = 'SELECT * FROM purchases WHERE user_id = ? AND category = ?';
    db.query(query, [userId, catetory], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        res.status(200).json({ success: true, purchases: results });
    });
});

app.get('/lists/:userId', (req, res) => {
    const userId = req.params.userId;

    const query = 'SELECT * FROM cs485group2.lists WHERE user_id = ?';
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        res.status(200).json({ success: true, lists: results });
    });
});

app.get('/listItems/:listId', (req, res) => {
    const listId = req.params.listId;

    const query = `
        SELECT * FROM cs485group2.purchases
        WHERE FIND_IN_SET(purchase_id, (SELECT purchases FROM lists WHERE id = ?))
    `;

    db.query(query, [listId], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        res.status(200).json({ success: true, purchases: results });
    });
});

app.get('/purchasesByIds', (req, res) => {
    const purchaseIds = req.query.ids;
    const query = `SELECT * FROM cs485group2.purchases WHERE purchase_id IN (${purchaseIds})`;
    db.query(query, (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }
        res.status(200).json({ success: true, purchases: results });
    });
});

app.post('/budget', (req, res) => {
    const { userId, budget, months } = req.body;

    if (!userId || !budget || !months) {
        return res.status(400).json({ success: false, message: "All fields are required!" });
    }

    const query = 'INSERT INTO budget (user_id, budget, months) VALUES (?, ?, ?)';
    db.query(query, [userId, budget, months], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        res.status(200).json({ success: true, message: 'Budget set successfully!' });
    });
});


app.get('/budget/:userId', (req, res) => {
    const userId = req.params.userId;

    const query = 'SELECT * FROM budget WHERE user_id = ?';
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: 'Database error!' });
        }

        if (results.length > 0) {
            res.status(200).json({ success: true, budget: results[0] });
        } else {
            res.status(200).json({ success: false, message: 'No budget found!' });
        }
    });
});

app.post('/addPurchase', (req, res) => {
    const { user_id, item_name, price, category, date_purchased } = req.body;

    if (!user_id || !item_name || !price || !category || !date_purchased) {
        return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    const query = 'INSERT INTO cs485group2.purchases (user_id, item_name, price, category, date_purchased) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [user_id, item_name, price, category, date_purchased], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ success: false, message: 'Database error.' });
        }

        res.status(200).json({ success: true, message: 'Purchase added successfully!', purchase_id: results.insertId });
    });
});


app.post('/addList', (req, res) => {
    const { userId, listName, purchaseIds } = req.body;

    console.log('Request payload:', req.body);

    if (!userId || !listName || !purchaseIds || purchaseIds.length === 0) {
        console.log('Missing required fields');
        return res.status(400).json({ success: false, message: "Missing required fields" });
    }

    let purchaseIdsString;
    if (Array.isArray(purchaseIds)) {
        purchaseIdsString = purchaseIds.join(',');
    } else if (typeof purchaseIds === 'string') {
        purchaseIdsString = purchaseIds;
    } else {
        console.log('Invalid purchaseIds format');
        return res.status(400).json({ success: false, message: "Invalid purchaseIds format" });
    }

    const query = 'INSERT INTO cs485group2.lists (user_id, list_name, purchases) VALUES (?, ?, ?)';
    console.log('Executing query:', query, [userId, listName, purchaseIdsString]);

    db.query(query, [userId, listName, purchaseIdsString], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: "Database error" });
        }

        console.log('List added successfully:', results);
        res.status(200).json({ success: true, message: "List added successfully", listId: results.insertId });
    });
});

app.post('/purchases', (req, res) => {
    const { user_id, item_name, price, category, date_purchased } = req.body;
    const query = 'INSERT INTO cs485group2.purchases (user_id, item_name, price, category, date_purchased) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [user_id, item_name, price, category, date_purchased], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ success: false, message: 'Error adding purchase' });
        }
        res.json(result.insertId);
    });
});
